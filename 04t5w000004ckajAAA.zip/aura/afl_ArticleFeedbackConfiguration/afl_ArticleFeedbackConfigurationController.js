({
	doInit : function(component, event, helper) {
		helper.getInitialData(component);
	},

	updateHashtag: function(component, event, helper) {
		helper.updateHashtagHelper(component);
	}
})