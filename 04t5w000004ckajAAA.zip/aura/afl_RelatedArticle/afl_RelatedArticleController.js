({
	doInit: function(component, event, helper) {
		helper.doInit(component, event, helper);
	},

	navigateTo : function(component, event, helper) {
		helper.navigateTo(component, event, helper);
	}
})